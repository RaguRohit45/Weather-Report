# Weather Dashboard 
This is a React + Vite weather dashboard that fetches and displays **global** weather data.

It supports:

- Search by location (city name, airport code, or `lat,long`)
- Current conditions (temperature, humidity, wind, condition)
- Forecast display when available

## Setup / run instructions

### Prerequisites

- Node.js (LTS recommended)
- An IndianAPI key for the Weather API

### 1) Install dependencies

From the `frontend/` folder:

```bash
npm install
```

### 2) Configure environment variables

Create a `.env` file inside `frontend/`:

```env
VITE_INDIANAPI_KEY=sk-live-yXtj9i4KVREeURgQyYySWD6gyln7OToQt5ksLF24
```

Notes:

- Vite only exposes environment variables that start with `VITE_`.
- Keep your API key private.

### 3) Start the dev server

```bash
npm run dev
```


### Provider

- IndianAPI Weather: https://indianapi.in/weather-api

### Base URL

```text
https://weather.indianapi.in
```

### Authentication

All requests include:

```text
x-api-key: <your api key>
```

### Endpoints used by this project

- `GET /global/weather?location=<string>&days=<1-3>`
- `GET /global/current?location=<string>` (used as a fallback if `/global/weather` is unavailable)

### Implementation location

- API client: `src/api/weatherApi.js`
- UI: `src/Home.jsx`
