import { useEffect, useMemo, useState } from 'react'
import { getGlobalWeatherWithFallback } from './api/weatherApi'

const DEFAULT_QUERY = ''

function formatTemp(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '—'
  return `${Number(value).toFixed(1)}°C`
}

function formatNumber(value) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '—'
  return String(value)
}

const Home = () => {
  const [query, setQuery] = useState(DEFAULT_QUERY)
  const [days, setDays] = useState(3)

  const [notice, setNotice] = useState('')

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [data, setData] = useState(null)

  const canSearch = useMemo(() => query.trim().length > 0, [query])

  const runSearch = async (e, override) => {
    e?.preventDefault?.()
    const effectiveQuery = override?.query ?? query
    const effectiveDays = override?.days ?? days
    if (!effectiveQuery.trim()) return

    setLoading(true)
    setError('')
    setNotice('')
    setData(null)
    try {
      const res = await getGlobalWeatherWithFallback(effectiveQuery.trim(), effectiveDays)
      setData({ kind: 'global', raw: res })
    } catch (err) {
      setError(err?.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    runSearch(null, { query: DEFAULT_QUERY, days: 3 })
  }, [])

  const global = data?.kind === 'global' ? data.raw : null

  const globalCurrent = global?.current
  const globalForecast = global?.forecast || []

  return (
    <div className="page">
      <div className="container">
        <header className="header">
          <div className="title">Weather Dashboard</div>
        </header>
 
        <div className="card">
          <form className="controls" onSubmit={runSearch}>
            <label className="field">
              <div className="label">Location (Global)</div>
              <input
                className="input"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={'e.g. Chennai / London / New York / 28.61,77.21'}
              />
            </label>

            <label className="field">
              <div className="label">Forecast days</div>
              <select className="select" value={days} onChange={(e) => setDays(Number(e.target.value))}>
                <option value={1}>1 day</option>
                <option value={2}>2 days</option>
                <option value={3}>3 days</option>
              </select>
            </label>

            <button className="primaryBtn" type="submit" disabled={!canSearch || loading}>
              {loading ? 'Loading…' : 'Search'}
            </button>
          </form>

          {!!notice && <div className="alert">{notice}</div>}

          {!!error && <div className="alert">{error}</div>}

          {!loading && !error && !data && (
            <div className="empty">Enter a city/location and click Search.</div>
          )}
        </div>

        {global && (
          <div className="grid">
            <div className="card">
              <div className="cardTitle">Current (Global)</div>
              <div className="kv">
                <div className="kvRow">
                  <div className="kvKey">Location</div>
                  <div className="kvVal">{global?.location || '—'}</div>
                </div>
                <div className="kvRow">
                  <div className="kvKey">Temperature</div>
                  <div className="kvVal">{formatTemp(globalCurrent?.temperature)}</div>
                </div>
                <div className="kvRow">
                  <div className="kvKey">Feels like</div>
                  <div className="kvVal">{formatTemp(globalCurrent?.feels_like)}</div>
                </div>
                <div className="kvRow">
                  <div className="kvKey">Humidity</div>
                  <div className="kvVal">{formatNumber(globalCurrent?.humidity)}</div>
                </div>
                <div className="kvRow">
                  <div className="kvKey">Wind</div>
                  <div className="kvVal">
                    {formatNumber(globalCurrent?.wind_speed)} {globalCurrent?.wind_direction ? `(${globalCurrent.wind_direction})` : ''}
                  </div>
                </div>
                <div className="kvRow">
                  <div className="kvKey">Condition</div>
                  <div className="kvVal">{globalCurrent?.condition || '—'}</div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="cardTitle">Forecast (Global)</div>
              <div className="forecast">
                {globalForecast.length === 0 ? (
                  <div className="empty">No forecast available.</div>
                ) : (
                  globalForecast.map((day) => (
                    <div key={day.date} className="forecastRow">
                      <div className="forecastDate">{day.date}</div>
                      <div className="forecastTemps">
                        <span className="pill">Max {formatNumber(day.max_temp)}°C</span>
                        <span className="pill">Min {formatNumber(day.min_temp)}°C</span>
                      </div>
                      <div className="forecastDesc">
                        {day.sunrise && day.sunset ? `${day.sunrise} → ${day.sunset}` : '—'}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
export default Home