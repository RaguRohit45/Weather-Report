const BASE_URL='https://weather.indianapi.in'

function getApiKey() {
  const key=import.meta.env.VITE_INDIANAPI_KEY
  if(!key) {
    throw new Error('Missing VITE_INDIANAPI_KEY')
  }
  return key
}

async function requestJson(path) {
  const apiKey=getApiKey()
  let res
  try {
    res=await fetch(`${BASE_URL}${path}`, {
      headers:{
        'x-api-key':apiKey,
      },
    })
  } catch (err) {
    const message=
      err?.message ||
      'Network error. This is often caused by CORS when calling the API directly from the browser.'
    throw new Error(message)
  }

  const text=await res.text()
  let data
  try {
    data=text?JSON.parse(text):null
  } catch {
    data=text
  }

  if (!res.ok) {
    const bodyMessage=
      typeof data==='string'
        ? data
        : data?.message||data?.error||data?.errors||null
    const snippet=
      typeof text==='string' && text.trim().length>0
        ? ` - ${text.trim().slice(0,200)}`
        : ''
    const message=bodyMessage
      ? `HTTP ${res.status} ${res.statusText} (${path}): ${String(bodyMessage)}${snippet}`
      : `HTTP ${res.status} ${res.statusText} (${path})${snippet||': Request failed'}`
    throw new Error(message)
  }

  return data
}

export async function getIndiaCities() {
  return requestJson('/india/cities')
}

let indiaCitiesCachePromise

async function getIndiaCitiesCached() {
  if (!indiaCitiesCachePromise) {
    indiaCitiesCachePromise=getIndiaCities()
  }
  return indiaCitiesCachePromise
}

export async function getIndiaWeatherByCity(city) {
  const q=new URLSearchParams({ city }).toString()
  return requestJson(`/india/weather?${q}`)
}

function isHttp500(err) {
  return String(err?.message || '').includes('HTTP 500')
}

function normalizeCityName(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[^a-z0-9 ]/g, '')
    .trim()
}

function pickBestCityId(citiesMap, query) {
  const q=normalizeCityName(query)
  if (!q) return null

  const entries=Object.entries(citiesMap || {})
  if (entries.length===0) return null

  // Score: exact match > startsWith > includes
  let best=null
  let bestScore=-1
  for (const [id, name] of entries) {
    const n=normalizeCityName(name)
    if (!n) continue
    let score=0
    if (n===q) score=3
    else if (n.startsWith(q)) score=2
    else if (n.includes(q)) score=1
    if (score>bestScore) {
      bestScore=score
      best={ id, name }
      if (bestScore===3) break
    }
  }
  return bestScore>0 ? best : null
}

function pickCandidateCityIds(citiesMap, query, limit = 10) {
  const q = normalizeCityName(query)
  if (!q) return []

  const entries = Object.entries(citiesMap || {})
  const scored = []
  for (const [id, name] of entries) {
    const n = normalizeCityName(name)
    if (!n) continue

    let score = 0
    if (n === q) score = 300
    else if (n.startsWith(q)) score = 200
    else if (n.includes(q)) score = 100
    if (score === 0) continue

    // Prefer shorter names when score ties
    score -= Math.min(n.length, 50)
    scored.push({ id, name, score })
  }

  scored.sort((a, b) => b.score - a.score)
  return scored.slice(0, limit)
}

export async function getIndiaWeatherByCityWithFallback(city) {
  // The /india/weather endpoint has been observed to return HTTP 500 with
  // "list index out of range" for some valid queries. Prefer stable ID-based API.
  const raw = String(city || '').trim()
  if (/^\d+$/.test(raw)) {
    return await getIndiaWeatherById(raw)
  }

  const cities=await getIndiaCitiesCached()
  const candidates = pickCandidateCityIds(cities, city, 10)
  if (candidates.length === 0) {
    throw new Error('City not found in Indian cities list. Try a different spelling or use Global mode.')
  }

  let lastErr
  for (const c of candidates) {
    try {
      return await getIndiaWeatherById(c.id)
    } catch (err) {
      lastErr = err
      if (isHttp500(err)) {
        try {
          return await getIndiaWeatherByCity(c.name)
        } catch (err2) {
          lastErr = err2
        }
      }
    }
  }

  throw lastErr || new Error('India weather service is currently unavailable')
}

export async function getIndiaWeatherById(cityId) {
  const q=new URLSearchParams({ city_id: String(cityId) }).toString()
  return requestJson(`/india/weather_by_id?${q}`)
}

export async function getGlobalCurrent(location) {
  const q=new URLSearchParams({ location }).toString()
  return requestJson(`/global/current?${q}`)
}

export async function getGlobalWeather(location, days = 3) {
  const q=new URLSearchParams({ location, days: String(days) }).toString()
  return requestJson(`/global/weather?${q}`)
}

export async function getGlobalWeatherWithFallback(location, days = 3) {
  try {
    return await getGlobalWeather(location, days)
  } catch (err) {
    const msg = String(err?.message || '')
    const is500 = msg.includes('HTTP 500')
    if (!is500) throw err

    const current = await getGlobalCurrent(location)
    return {
      location,
      current,
      forecast: [],
    }
  }
}
